package com.nalitnyk.lab2;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Lw2Application {

	public static void main(String[] args) {
		SpringApplication.run(Lw2Application.class, args);
	}

}
